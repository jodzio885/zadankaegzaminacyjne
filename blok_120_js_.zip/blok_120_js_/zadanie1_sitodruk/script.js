// Twoje rozwiazanie
const oblicz = document.getElementById('oblicz');

oblicz.addEventListener('click', function(){
    let nadruk = document.getElementById('nadruk').value;
    let sztuki = parseInt(document.getElementById('sztuki').value);
    let wynik = document.getElementById('wynik');
    let kwota = 0;

    kwota = sztuki*nadruk;

    wynik.innerHTML = kwota;
});