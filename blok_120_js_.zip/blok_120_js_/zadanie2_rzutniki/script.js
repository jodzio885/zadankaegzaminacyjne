// Twoje rozwiazanie
const oblicz = document.getElementById('oblicz');

oblicz.addEventListener('click', function(){
    let dni = parseInt(document.getElementById('dni').value);
    let statyw = document.getElementById('statyw').checked;
    let pilot = document.getElementById('pilot').checked;

    const wynik = document.getElementById('wynik');
    let kwota = 0;

    if(statyw == true && pilot == true){
        kwota = dni*35+20+15;
        wynik.innerHTML = kwota;
    }else if(statyw == true && pilot == false){
        kwota = dni*35+20;
        wynik.innerHTML = kwota;
    }else if(pilot == true && statyw == false){
        kwota = dni*35+15;
        wynik.innerHTML = kwota;
    }else{
        kwota = dni*35;
        wynik.innerHTML = kwota;
    }
});
