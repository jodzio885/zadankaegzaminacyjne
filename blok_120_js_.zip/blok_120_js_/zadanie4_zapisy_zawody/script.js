// Twoje rozwiazanie
const zapisz = document.getElementById('zapisz');

zapisz.addEventListener('click', function(e){
    e.preventDefault();
    let imie = document.getElementById('imie').value;
    let osoby = parseInt(document.getElementById('osoby').value);

    const wynik =document.getElementById('wynik');
    const blad =document.getElementById('blad');

    if(imie.trim() === ''){
        wynik.innerHTML = "";
        blad.innerHTML = "Podaj imię i nazwisko";
    }else if(osoby<1 || osoby>4 || !Number.isInteger(osoby)){
        wynik.innerHTML = "";
        blad.innerHTML = "Liczba osób musi być od 1 do 4";
    }else{
        wynik.innerHTML = `Zapisano ${imie}. Liczba osób:${osoby}`;
    }

});